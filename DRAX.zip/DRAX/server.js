const express = require('express');
const http = require('http');
const { Server } = require("socket.io");
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// Serve file HTML dan aset statis
app.use(express.static(__dirname));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'game.html'));
});

let players = {};

io.on('connection', (socket) => {
    if (Object.keys(players).length >= 5) {
        socket.emit('serverFull', 'Server penuh! Maksimal 5 orang.');
        socket.disconnect();
        return;
    }

    players[socket.id] = { 
        id: socket.id,
        x: 0, z: 0, speed: 0,
        name: "Racer_" + Math.floor(Math.random() * 100),
        model: 'standar',
        color: Math.floor(Math.random() * 0xffffff) 
    };
    
    io.emit('updatePlayers', players);
    io.emit('chatMessage', `[SERVER]: ${players[socket.id].name} masuk ke lobby!`);

    socket.on('updatePosition', (data) => {
        if(players[socket.id]) {
            players[socket.id].x = data.x;
            players[socket.id].z = data.z;
            players[socket.id].speed = data.speed;
            io.emit('updatePlayers', players);
        }
    });

    socket.on('chatMessage', (msg) => {
        if(players[socket.id]) {
            io.emit('chatMessage', `${players[socket.id].name}: ${msg}`);
        }
    });

    socket.on('disconnect', () => {
        if(players[socket.id]) {
            io.emit('chatMessage', `[SERVER]: ${players[socket.id].name} keluar dari lobby.`);
            delete players[socket.id];
            io.emit('updatePlayers', players);
        }
    });
});

const PORT = process.env.PORT || 3370;
server.listen(PORT, () => console.log(`Server jalan di port ${PORT}`));